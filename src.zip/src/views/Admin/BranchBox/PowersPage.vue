<template>
  <div class="powersPage">
    <div class="container">
      <h4>الصلاحيات</h4>
      <p>
        التي تشمل الخدمات والمنتجات التي تعزز تجربة العميل وتجعلها فاخرة ومريحة
      </p>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>نقطة البيع</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>المبيعات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>عمولات الموظفين</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>مقدمو الخدمات العامة</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>الموردون</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>العملاء</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>المصاريف العمومية</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>المشتريات النثرية</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>مشتريات المنتجات</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>السلفيات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير المبيعات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>صندوق الكاشير</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الخدمات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الضريبة للمبيعات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير اليوميات</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الموظف الإجمالي</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير مسير الرواتب</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير مشتريات المنتجات</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الضريبة للمشتريات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>الحجوزات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الموظف المفصل</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير الخصومات والسلفيات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>المنتجات النثرية</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير إقفال الحسابات</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>بنود المصاريف العمومية</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>فواتير المبيعات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>تقرير تصفية العمولات</span>
          </div>
        </div>
      </div>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>الخدمات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>الخصومات</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>المنتجات</span>
          </div>
        </div>
      </div>
      <h4>الصلاحيات لوحة التحكم</h4>
      <div class="rolls row">
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>التقرير الإجمالي لليوم</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>إجمالي مبيعات الموظفين لليوم</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>موظف اليوم</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>التقرير الإجمالي للشهر الحالي</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>إجمالي مبيعات الموظفين لشهر الحالي</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>موظف الشهر</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>التقرير الإجمالي الكلي</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>إجمالي مبيعات الموظفين الكلي</span>
          </div>
        </div>
        <div class="col-md-4 roll">
          <div class="card">
            <input
              class="form-check-input"
              type="checkbox"
              value=""
              id="flexCheckDefault"
            />
            <span>الموظف الأفضل</span>
          </div>
        </div>
      </div>
    </div>
    <button class="btn">إرسال</button>
  </div>
</template>
<script>
export default {
  name: "PowersPage",
};
</script>
<style scoped>
.row {
  margin: 0;
}
.powersPage {
  direction: rtl;
  width: 80%;
}
.powersPage h4 {
  color: #3f51b5;
  font-weight: 700px;
}
.powersPage h4:last-of-type {
  margin: 5vh 0;
}
.powersPage p {
  color: #1a2669;
  font-weight: 400;
}
.powersPage .rolls:first-of-type {
  margin-top: 5vh;
}
.powersPage .card {
  display: block;
  padding: 1vh;
  background: #ebedf7;
  border: 1px solid #ebedf7;
  text-align: center;
  color: #1a2669;
  margin-bottom: 2vh;
}
.powersPage input[type="checkbox"] {
  margin-right: 1vh;
  width: 3vh;
  border: 2px solid #3f51b5;
  height: 3vh;
  position: absolute;
  right: 0;
}
.powersPage .card span {
  font-weight: 600;
}
.powersPage button {
  background: #3f51b5;
  color: #fff;
  border: 1px solid #3f51b5;
  padding: 1vh 5vh;
  display: block;
  width: auto;
  margin: 2vh auto;
}

@media (max-width: 991px) {
  .powersPage {
    width: 70%;
  }
}
@media (max-width: 765px) {
  .powersPage {
    width: 100%;
  }
}
@media (max-width: 540px) {
}
</style>
