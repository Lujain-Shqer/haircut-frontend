export default (await import('vue')).defineComponent({
name: "PointOfSales",
components: {
ServicesPage,
},
methods: {
showDetails() {
}
}
});
